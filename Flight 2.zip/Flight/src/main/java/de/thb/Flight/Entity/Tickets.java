package de.thb.Flight.Entity;

public class Tickets {

    Flight flight;
    Customer vorname;
    Customer nachname;
}
