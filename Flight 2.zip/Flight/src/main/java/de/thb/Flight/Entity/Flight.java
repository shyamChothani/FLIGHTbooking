package de.thb.Flight.Entity;

import java.util.ArrayList;
import java.util.Date;

public class Flight {

    int flightNo;
    Date arrivalDate;
    Date departureDate;
    ArrayList<Seats> seat;

}
